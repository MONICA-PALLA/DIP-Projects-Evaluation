img_name='rabbit.bmp';
scribs_img_name='rabbit_m.bmp';


levels_num=1;
active_levels_num=1;

sig=0.1^6;

runMatting